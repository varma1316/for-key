#!/bin/bash
export AWS_PAGER=""
source "/usr/local/bin/judge/test/common.sh"

TestDeployment() {
    print_status "info" "Checking Deployment 'stateful-app'..."
    kubectl get deployment stateful-app &>/dev/null \
      && print_status "success" "Deployment exists." \
      || { print_status "failed" "Deployment not found."; return; }

    POD=$(kubectl get pods -l app=stateful-app -o jsonpath='{.items[0].status.phase}')
    if [ "$POD" == "Running" ]; then
      print_status "success" "Pod is Running."
    else
      print_status "failed" "Pod status: $POD"
    fi
}

TestDeployment
