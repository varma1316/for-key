#!/bin/bash
export AWS_PAGER=""
source "/usr/local/bin/judge/test/common.sh"

TestPVandPVC() {
    print_status "info" "Checking PersistentVolume 'nfs-pv'..."
    PV_STAT=$(kubectl get pv nfs-pv -o jsonpath='{.status.phase}' 2>/dev/null)
    if [ "$PV_STAT" == "Bound" ]; then
      print_status "success" "PV nfs-pv is Bound."
    else
      print_status "failed" "PV status: $PV_STAT"
    fi

    print_status "info" "Checking PersistentVolumeClaim 'nfs-pvc'..."
    PVC_STAT=$(kubectl get pvc nfs-pvc -o jsonpath='{.status.phase}' 2>/dev/null)
    if [ "$PVC_STAT" == "Bound" ]; then
      print_status "success" "PVC nfs-pvc is Bound."
    else
      print_status "failed" "PVC status: $PVC_STAT"
    fi
}

TestPVandPVC
