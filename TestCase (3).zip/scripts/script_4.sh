#!/bin/bash
export AWS_PAGER=""
source "/usr/local/bin/judge/test/common.sh"

TestNodeGroup() {
    REGION="us-west-2"
    ACCOUNT_ID=$(aws sts get-caller-identity \
      --query Account --output text --region "$REGION")
    CLUSTER="lab-eks-${ACCOUNT_ID}"
    NG="lab-ng-${ACCOUNT_ID}"

    print_status "info" "Describing node group '$NG'..."
    NGD=$(aws eks describe-nodegroup \
      --region "$REGION" \
      --cluster-name "$CLUSTER" \
      --nodegroup-name "$NG" 2>/dev/null) || {
      print_status "failed" "Node group not found."; return
    }
    print_status "success" "Node group exists."

    ST=$(echo "$NGD" | jq -r '.nodegroup.status')
    [ "$ST" == "ACTIVE" ] && print_status "success" "Status ACTIVE." \
      || print_status "failed" "Status $ST"

    DES=$(echo "$NGD" | jq -r '.nodegroup.scalingConfig.desiredSize')
    MIN=$(echo "$NGD" | jq -r '.nodegroup.scalingConfig.minSize')
    MAX=$(echo "$NGD" | jq -r '.nodegroup.scalingConfig.maxSize')
    TYPE=$(echo "$NGD" | jq -r '.nodegroup.instanceTypes[0]')

    if [ "$MIN" -eq 1 ] && [ "$DES" -eq 2 ] && [ "$MAX" -eq 3 ]; then
      print_status "success" "Scaling is 1/2/3."
    else
      print_status "failed" "Scaling is $MIN/$DES/$MAX."
    fi

    [ "$TYPE" == "t3.micro" ] && print_status "success" "Instance type t3.micro." \
      || print_status "failed" "Type $TYPE."
}

TestNodeGroup
