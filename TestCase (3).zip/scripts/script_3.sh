#!/bin/bash
export AWS_PAGER=""
source "/usr/local/bin/judge/test/common.sh"

TestEKSCluster() {
    REGION="us-west-2"
    ACCOUNT_ID=$(aws sts get-caller-identity \
      --query Account --output text --region "$REGION")
    CLUSTER="lab-eks-${ACCOUNT_ID}"

    print_status "info" "Checking cluster '$CLUSTER' status..."
    STATUS=$(aws eks describe-cluster \
      --region "$REGION" \
      --name "$CLUSTER" \
      --query "cluster.status" --output text 2>/dev/null)
    if [ "$STATUS" == "ACTIVE" ]; then
      print_status "success" "Cluster is ACTIVE."
    else
      print_status "failed" "Status: $STATUS"; return
    fi

    print_status "info" "Verifying public-only endpoint..."
    PUB=$(aws eks describe-cluster \
      --region "$REGION" \
      --name "$CLUSTER" \
      --query "cluster.resourcesVpcConfig.endpointPublicAccess" --output text)
    PRI=$(aws eks describe-cluster \
      --region "$REGION" \
      --name "$CLUSTER" \
      --query "cluster.resourcesVpcConfig.endpointPrivateAccess" --output text)
    if [ "$PUB" == "True" ] && [ "$PRI" == "False" ]; then
      print_status "success" "Endpoint is public-only."
    else
      print_status "failed" "endpointPublic=$PUB, endpointPrivate=$PRI"
    fi

    for ADD in vpc-cni kube-proxy; do
      print_status "info" "Checking addon '$ADD'..."
      COUNT=$(aws eks list-addons \
        --region "$REGION" \
        --cluster-name "$CLUSTER" \
        --query "addons[?@=='$ADD'] | length(@)" \
        --output text)
      if [ "$COUNT" -ge 1 ]; then
        print_status "success" "Addon $ADD installed."
      else
        print_status "failed" "Addon $ADD missing."
      fi
    done
}

TestEKSCluster
