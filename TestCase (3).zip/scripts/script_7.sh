#!/bin/bash
export AWS_PAGER=""
source "/usr/local/bin/judge/test/common.sh"

TestService() {
    print_status "info" "Checking Service 'stateful-service'..."
    kubectl get svc stateful-service &>/dev/null \
      && print_status "success" "Service exists." \
      || { print_status "failed" "Service not found."; return; }

    IP=$(kubectl get svc stateful-service -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
    if [ -n "$IP" ]; then
      print_status "success" "External endpoint: $IP"
    else
      print_status "failed" "No external IP/hostname yet."
    fi
}

TestService
