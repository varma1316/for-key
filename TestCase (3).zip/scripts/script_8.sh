#!/bin/bash
export AWS_PAGER=""
source "/usr/local/bin/judge/test/common.sh"

TestEndpoint() {
    HOST=$(kubectl get svc stateful-service -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
    if [ -z "$HOST" ]; then
      print_status "failed" "No LoadBalancer hostname."
      return
    fi
    RESP=$(curl -s --max-time 15 http://$HOST/log.txt || true)
    if [ -n "$RESP" ]; then
      print_status "success" "Received log output."
    else
      print_status "failed" "No response or timed out."
    fi
}

TestEndpoint
