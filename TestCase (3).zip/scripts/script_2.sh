#!/bin/bash
export AWS_PAGER=""
source "/usr/local/bin/judge/test/common.sh"

TestIAMNodeRole() {
    ROLE="EKSNodeRole"
    POLICIES=(
      "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly"
      "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
      "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
      "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
    )

    print_status "info" "Checking IAM role '$ROLE'..."
    aws iam get-role --role-name "$ROLE" >/dev/null 2>&1 \
      && print_status "success" "Role exists." \
      || { print_status "failed" "Role not found."; return; }

    for P in "${POLICIES[@]}"; do
      print_status "info" "Verifying policy '$P' attached..."
      COUNT=$(aws iam list-attached-role-policies \
        --role-name "$ROLE" \
        --query "AttachedPolicies[?PolicyArn=='$P'] | length(@)" \
        --output text)
      if [ "$COUNT" -ge 1 ]; then
        print_status "success" "Attached: $P"
      else
        print_status "failed" "Missing: $P"
      fi
    done
}

TestIAMNodeRole
